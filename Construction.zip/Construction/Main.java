package DataStructureAssignmentSolution.Construction;

public class Main {
    public static void main(String[] args) {
        Construction construction = new Construction();
        construction.getIData();
        construction.orderCalculator(construction.floorSize);
    }
}